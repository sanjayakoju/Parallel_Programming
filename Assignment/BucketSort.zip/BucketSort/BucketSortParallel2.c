#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <omp.h>

#define n 100000
#define bsize 100000
#define bNum 1000
#define thCount 8

int finalList[n];
int bucket[bNum][n];
int count[bNum];

int list[n];
int i, j, k, range, maxval, minval, bindex;

clock_t t;
omp_lock_t DL[bNum];

int main() {

	minval = 100000;
	maxval = -100000;

	for (i = 0; i < n; i++) {
		list[i] = abs(rand() % 100000 + 1);
		if (minval >= list[i]) minval = list[i];
		if (maxval <= list[i]) maxval = list[i];
	}
	for (i = 0;i < bNum;i++) {
		count[i] = 0;
		omp_init_lock(&DL[i]);
	}
	range = maxval - minval + 1;
	t = clock();
	omp_set_num_threads(thCount);
	#pragma omp parallel for private(bindex)
	for (i = 0;i < n;i++) {
		bindex = (int)((float)bNum * ((float)(list[i] - minval) / range));
		omp_set_lock(&DL[bindex]);
		bucket[bindex][count[bindex]] = list[i];
		count[bindex] += 1;
		omp_unset_lock(&DL[bindex]);
	}
	printf("Distribution Phase: ");
	printf("Thread %d Elapsed Time : %d\n", thCount, clock() - t);


	t = clock();
	omp_set_num_threads(thCount);
	#pragma omp parallel for private(j,k)
	for (i = 0;i < bNum;i++) {
		for (j = 0; j < count[i] - 1; j++)
		{
			for (k = 0; k < count[i] - j - 1; k++)
			{
				if (bucket[i][k] > bucket[i][k + 1]) {
					omp_set_lock(&DL[i]);
					int temp = bucket[i][k];
					bucket[i][k] = bucket[i][k + 1];
					bucket[i][k + 1] = temp;
					omp_unset_lock(&DL[i]);
				}
			}
		}
	}
	printf("Sort Phase: ");
	printf("Thread %d Elapsed Time : %d\n", thCount, clock() - t);

	t = clock();
	omp_set_num_threads(thCount);
	#pragma omp parallel for private(k)
	for (j = 0;j < bNum;j++) {
		for (k = 0;k < count[j];k++) {
			omp_set_lock(&DL[j]);
			finalList[i] = bucket[j][k];
			i++;
			omp_unset_lock(&DL[j]);
		}
	}
	printf("Merge Phase: ");
	printf("Thread %d Elapsed Time : %d\n", thCount, clock() - t);
	for (i = 0;i < bNum;i++) {
		omp_destroy_lock(&DL[i]);
	}
}